# The trees dataset with point locations of trees
trees.head()