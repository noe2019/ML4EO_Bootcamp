# Does the Montparnasse district contains the bike station?
print(district_montparnasse.contains(bike_station))