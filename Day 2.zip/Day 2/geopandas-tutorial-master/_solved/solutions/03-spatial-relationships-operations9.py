# The distance to the closest station
dist_eiffel.min()