# Create a boolean Series
mask = districts.contains(eiffel_tower)
mask