# Inspect the result
trees_by_district.head()