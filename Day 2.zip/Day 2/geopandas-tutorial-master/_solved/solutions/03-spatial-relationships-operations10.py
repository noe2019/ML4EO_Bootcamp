# Filter the restaurants for closer than 1 km
stations_eiffel = stations[dist_eiffel < 1000]