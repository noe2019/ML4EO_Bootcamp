# The distance between the Eiffel Tower and the bike station?
print(eiffel_tower.distance(bike_station))