# Import the districts dataset
districts = geopandas.read_file("data/paris_districts.geojson")