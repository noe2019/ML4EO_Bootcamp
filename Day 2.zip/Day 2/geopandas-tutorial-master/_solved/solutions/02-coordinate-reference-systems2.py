# Check the CRS information
districts.crs