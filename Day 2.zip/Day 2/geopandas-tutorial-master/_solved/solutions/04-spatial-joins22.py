# Print the first five rows of the result
combined.head()