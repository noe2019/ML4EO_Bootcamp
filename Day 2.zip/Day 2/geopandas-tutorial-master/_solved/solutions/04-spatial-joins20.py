# Plot the intersection
land_use_muette.plot(edgecolor='black')