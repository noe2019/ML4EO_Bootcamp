# The distance from each stations to the Eiffel Tower
dist_eiffel = stations.distance(eiffel_tower)