# dividing by 10^6 for showing km²
districts['area'] = districts.geometry.area / 1e6