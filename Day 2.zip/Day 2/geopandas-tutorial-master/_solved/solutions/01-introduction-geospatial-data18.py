# Make a plot of the districts colored by the population density
districts.plot(column='population_density', figsize=(12, 6), legend=True)