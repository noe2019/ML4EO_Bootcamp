# Calculate the area of all districts
districts.geometry.area