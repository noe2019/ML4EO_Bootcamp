stations = geopandas.read_file("data/paris_bike_stations.geojson")
stations.head()