# Plot the intersection
geopandas.GeoSeries([intersection]).plot()