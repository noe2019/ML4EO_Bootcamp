# Calculate the area of all districts (the result is now expressed in m²)
districts_RGF93.geometry.area