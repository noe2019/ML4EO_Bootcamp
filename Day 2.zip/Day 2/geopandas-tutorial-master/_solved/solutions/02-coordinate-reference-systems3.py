# Show the first rows of the GeoDataFrame
districts.head()