# Calculate the intersection of both polygons
intersection = park_boulogne.intersection(muette)