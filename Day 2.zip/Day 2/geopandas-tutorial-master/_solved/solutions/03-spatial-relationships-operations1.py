# Construct a point object for the Eiffel Tower
eiffel_tower = Point(648237.3, 6862271.9)