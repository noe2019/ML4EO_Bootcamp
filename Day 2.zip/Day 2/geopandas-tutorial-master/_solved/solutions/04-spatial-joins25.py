# Visualize the land use of the Muette district
land_use_muette.plot(column='class')