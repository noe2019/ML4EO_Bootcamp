# Print proportion of district area that occupied park
print(intersection.area / muette.area)