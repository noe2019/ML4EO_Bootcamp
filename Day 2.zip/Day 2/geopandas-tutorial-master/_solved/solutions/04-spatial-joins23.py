# Add the area as a column
combined['area'] = combined.geometry.area