# Take a subset for the Muette district
land_use_muette = combined[combined['district_name'] == 'Muette']