# Plot the districts dataset
districts.plot()