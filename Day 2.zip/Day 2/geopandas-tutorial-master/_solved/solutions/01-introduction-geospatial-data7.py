ax = stations.plot(figsize=(12,6), markersize=5)
contextily.add_basemap(ax)