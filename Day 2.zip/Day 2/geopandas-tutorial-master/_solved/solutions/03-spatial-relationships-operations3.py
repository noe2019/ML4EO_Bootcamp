# Is the Eiffel Tower located within the Montparnasse district?
print(eiffel_tower.within(district_montparnasse))