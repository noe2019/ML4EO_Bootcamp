# Add the area as a new column
land_use['area'] = land_use.geometry.area