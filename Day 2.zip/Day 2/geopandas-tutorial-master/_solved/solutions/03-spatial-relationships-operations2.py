# Print the result
print(eiffel_tower)