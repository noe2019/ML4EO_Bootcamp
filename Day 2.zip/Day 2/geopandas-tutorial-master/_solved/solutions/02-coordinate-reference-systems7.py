# Plot the districts dataset again
districts_RGF93.plot()