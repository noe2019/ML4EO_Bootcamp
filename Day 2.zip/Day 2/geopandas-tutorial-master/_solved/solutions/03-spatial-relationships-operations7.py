# Filter the districts with the boolean mask
districts[mask]